<?php
  include 'header.php';
?>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Xoho Project Demo.</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link href="main.css" rel="stylesheet">
<script type="text/javascript">
    validate_checkin();
     function validate_checkin(){
   $.ajax({
        url: "timer.php",
        type: "POST",
        dataType:'json',
        encode: true,
        data:'flag=2',
        cache: false,
        success: function(data)
        {   
           if(data.type != 'error')
            {
                 document.getElementById("check-in").disabled=true;

            }else{
                document.getElementById("check-in").disabled=false;
                document.getElementById("cheek-out").disabled=true;
               }
        },
        error: function(xhr, status, error) {
            alert(xhr.responseText+"-"+status+"-"+error);
            alert("just an error");
        }         
 });
}
   function send_checkin_time(){
    var hours=d.getHours();
    if(hours>12)
    {
        hours-=12;
    }
    var min=d.getMinutes();
    if(min<10){
        min='0'+min;
    }
    if(hours<10){
        hours='0'+hours;
    }
    checkin_time=hours+":"+min;
   var datastring='checkin_time='+ checkin_time +'&flag='+1;
    alert(datastring);
   $.ajax({
        url: "timer.php",
        type: "POST",
        dataType:"json",
        encode:true,
        data:datastring,   
        cache: false,
        success: function(data)
        {   
            if(data.type != 'error')
            {
                  document.getElementById("check-in").disabled=true;

            }else{
                document.getElementById("check-in").disabled=false;
            }
        },
        error: function() 
        {
            alert("*please check your connection and try again");
        }           
 });
}
</script>
</head>
<body onload="retrival()">
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    <div class="app-header__content">
                
                
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">

                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                            <img width="42" class="rounded-circle" src="assets/images/avatars/2.jpg" alt="">
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                            <p tabindex="0" class="dropdown-item" ><?php echo $_SESSION['name']; ?></p>
                                            <button type="button" tabindex="0" class="dropdown-item">Settings</button>
                                            <button type="button" tabindex="0" class="dropdown-item" onclick="location='logout.php';">Logout</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading">
                                        User
                                    </div>
                                    <div class="widget-subheading">
                                        Admin
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>        </div>
            </div>
        </div>           <div class="app-main">
                <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <ul class="vertical-nav-menu">
                                <li class="app-sidebar__heading">Staff Profile</li>
                                <li>
                                    
                                    <li>
                                    <a href="index.html">
                                        <i class="metismenu-icon pe-7s-angle-right-circle"></i>
                                        Main
                                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                             <a href="addqualifications.html" >
                                        <i class="metismenu-icon pe-7s-angle-right-circle"></i>
                                        Add Qualifiations
                                    </a>
                                        </li>
                                        <li>
                                            <a href="addexperience.html" >
                                        <i class="metismenu-icon pe-7s-angle-right-circle"></i>
                                        Add Experience
                                    </a>
                                        </li>
                                        <li>
                                            <a href="addpublication.html" >
                                        <i class="metismenu-icon pe-7s-angle-right-circle"></i>
                                        Add Publications
                                    </a>
                                        </li>
                                        <li>
                                            <a href="addcertifications.html" >
                                        <i class="metismenu-icon pe-7s-angle-right-circle"></i>
                                        Add Certifications
                                    </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="app-sidebar__heading">SAMS</li>
                                <li>
                                    <a href="clforms.html">
                                        <i class="metismenu-icon pe-7s-news-paper">
                                        </i>Apply for Leave
                                    </a>
                                   
                                </li>
                                <li>
                                    <a href="whforms.html">
                                        <i class="metismenu-icon pe-7s-clock">
                                        </i>Apply for WH
                                    </a>
                                </li>
                                <li>
                                    <a href="index.html">
                                        <i class="metismenu-icon pe-7s-target">
                                        </i>FingerPrint Reading
                                    </a>
                                </li>
                                <li>
                                        <a href="approval.html">
                                            <i class="metismenu-icon pe-7s-pen">
                                            </i>Approval
                                        </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>    <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                                  <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-midnight-bloom">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Available CL</div>
                                            <div class="widget-subheading">Current Year</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>0</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-arielle-smile">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Available WH</div>
                                            <div class="widget-subheading">Current Year</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>0</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-grow-early">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Available OD</div>
                                            <div class="widget-subheading">Current Year</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>0</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
               
                      
                       </div>
                       <div class="col-md-6">
                                        <div class="main-card mb-3 card">
                                            <div class="card-body"><h5 id="today"class="card-title"></h5>
                                                <form class="">
                                                        <div class="position-relative form-group"><label for="exampleEmail" class="">Time</label><input id="demo" type="text" placeholder="" class="form-control" disabled/></div>
                                            <button class="mb-2 mr-2 btn btn-primary" id="check-in" onclick="send_checkin_time()">Check-in
                                        </button>
                                        <button class="mb-2 mr-2 btn btn-primary" id="Check-out" onclick="send_checkout_time()" >Check-out
                                        </button>
                                           </form>
                                           
                                </div>
                            </div>
                        </div>
                        <script>
                                myfun();
                                function myfun(){
                            var d = new Date();
                            var hours=d.getHours();
                            if(hours>12)
                            {
                                hours-=12;
                            }
                            var hours=hours.toString();
                            var min=d.getMinutes().toString();
                            var sec=d.getSeconds().toString();
                            
                            document.getElementById("demo").value = hours+":"+min+":"+sec;
                                               var t = setTimeout(myfun, 500);
                                                }
                                            </script>
                                            <script>
                                            var d = new Date();
                                            var weekday= new Array(7);
                                            weekday[0]="Sunday";
                                            weekday[1]="Monday";
                                            weekday[2]="Tuesday";
                                            weekday[3]="Wednesday";
                                            weekday[4]="Thursday";
                                            weekday[5]="Friday";
                                            weekday[6]="Saturday";

                                            var days=weekday[d.getDay()];
                                            document.getElementById("today").innerHTML= "Today"+" "+days;
                                            </script>
                        
                
        </div>
    </div>
    <script type="text/javascript" src="assets/scripts/main.js"></script>
</body>

<!-- Mirrored from demo.dashboardpack.com/architectui-html-free/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Sep 2019 04:51:38 GMT -->
</html>
