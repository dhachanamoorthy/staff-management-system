<?php
		session_start();
		if(!isset($_SESSION["username"])){
			echo "<script>
			window.location='login.html';
			</script>";
		}
		else {
			$con=new mysqli("localhost","root","","xoho");
			$sql="SELECT * FROM employee WHERE email='".$_SESSION['username']."'";
			$result=$con->query($sql);
			$row=$result->fetch_assoc();
			$_SESSION['emp_id']=$row['emp_id'];
			$_SESSION["name"]=$row["name"];
		}
?>