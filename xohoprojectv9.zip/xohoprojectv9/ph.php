<?php
$con=new mysqli("localhost","root","","xoho");
$sql="INSERT INTO time_stamp(emp_id) SELECT employee.emp_id FROM employee";
$result=$con->query($sql);
?>