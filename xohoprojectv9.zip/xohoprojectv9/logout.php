 <?php
  session_start();
  unset($_SESSION['username']);
 unset($_SESSION['upload']);
 session_destroy();
 header('Location: login.html');
  ?>