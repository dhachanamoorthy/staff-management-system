
<?php
	$username=$_POST['username'];
	$password=$_POST['password'];
	$encrypt=base64_encode($password);
    $con=new mysqli("localhost","root","","xoho");
	$sql="SELECT * FROM employee WHERE email='$username' and password='$encrypt'";

	$result = mysqli_query($con,$sql);
	$row = $result->num_rows;
   if ($row=$result->fetch_assoc()){
      	$output = json_encode(array('type' => 'message', 'text' => 'login successful'));
        session_start();
        $_SESSION['username']=$username;
        die($output);
          }
   else {
   	  $output = json_encode(array('type' => 'error', 'text' => 'username or password doesnt match'));
      die($output);
   }
?>
