<?php
	$flag=1;//$_POST['flag'];
    $con=new mysqli("localhost","root","","xoho");
    if($flag==1){
    	$checkin=1;
    	//$checkin_time=$_POST['checkin_time'];
    	$checkin_time='10:30s';
    	$d=date('d');
		$m=date('m');
		$y=date('Y');
		$on_data=$y."-".$m."-".$d;
		$sql1="SELECT * FROM employee WHERE email='".$_SESSION['username']."'";
		$result1=$con->query($sql1);
		$row=$result1->fetch_assoc();
		$_SESSION['emp_id']=$row['emp_id'];
		$_SESSION['name']=$row["name"];
		$emp_id=$_SESSION['emp_id'];
		$sql="UPDATE time_stamp set checkin='$checkin',checkin_time='$checkin_time',data='$on_data' where emp_id='$emp_id' and date='$on_data'";
		$result = mysqli_query($con,$sql);
		$row = $result->num_rows;
   if ($row=$result->fetch_assoc()){
      	$output = json_encode(array('type' => 'message', 'text' => 'login successful'));
        session_start();
        die($output);
          }
   else {
   	  $output = json_encode(array('type' => 'error', 'text' => 'username or password doesnt match'));
      die($output);
   }
  }
?>