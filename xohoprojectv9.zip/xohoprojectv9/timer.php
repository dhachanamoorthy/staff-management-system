<?php
include 'header.php';
	$flag=$_POST['flag'];//$_POST['flag'];
if($flag==1){
	$checkin=1;
	$checkin_time=$_POST['checkin_time'];
	$d=date('d');
	$m=date('m');
	$y=date('Y');
	$on_data=$y."-".$m."-".$d;
	$emp_id=$_SESSION['emp_id'];
	$sql="UPDATE time_stamp set checkin='$checkin',checkin_time='$checkin_time',date='$on_data' where emp_id='$emp_id'";
	$result=$con->query($sql);
	if(!mysqli_query($con,$sql)){
		$output = json_encode(array('type' => 'error', 'text' => 'Could not able to check in'));
		die($output);
	}
	else
	{
        $output = json_encode(array('type' => 'message', 'text' => 'successfully updated'));
		die($output);
		
	}
}
if($flag==2){
  $d=date('d');
  $m=date('m');
  $y=date('Y');
  $on_date=$y."-".$m."-".$d;
  $emp_id=$_SESSION['emp_id'];
  $sql="SELECT * FROM time_stamp WHERE emp_id='$emp_id' and date='$on_date'";
	$result = mysqli_query($con,$sql);
	$row = $result->num_rows;
   if ($row=$result->fetch_assoc()){
      	$output = json_encode(array('type' => 'message', 'text' => 'checkedin'));
        die($output);
          }
   else {
   	  $output = json_encode(array('type' => 'error', 'text' => 'username no checked in..'));
      die($output);
   }
}
?>