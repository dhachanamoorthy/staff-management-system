-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2019 at 06:57 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xoho`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `staff_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `pic` varchar(50) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `position` varchar(30) DEFAULT NULL,
  `dept` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`staff_id`, `name`, `pic`, `email`, `dob`, `emp_id`, `gender`, `mobile`, `password`, `role`, `position`, `dept`) VALUES
(5, 'Dhachanamoorthy N', NULL, 'dhachanamoorthyn@siet.ac.in', NULL, 123467, 'male', '7639619985', 'MTIz', 'chairman', 'chairman', 'aeronautical'),
(6, 'dhachana Moorthy', NULL, 'dhachanamoorthyn2021@siet.ac.i', NULL, 1234567, 'male', '7639619985', 'MTIz', 'chairman', 'chairman', 'aeronautical'),
(19, 'dhachana Moorthy', NULL, 'dhachanamoorthyn2021@siet.ac.i', NULL, 1234568, 'male', '7639619985', 'MTIz', 'chairman', 'chairman', 'aeronautical');

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE `main` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(40) NOT NULL,
  `no_of_emp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`dept_id`, `dept_name`, `no_of_emp`) VALUES
(1, 'aeronautical', 0),
(2, 'agriculture', 0),
(3, 'automobile', 0),
(4, 'bio_medical', 0),
(5, 'bio_technology', 0),
(6, 'cdc_non_tech', 0),
(7, 'cdc_tech', 0),
(8, 'chemistry', 0),
(9, 'civil', 0),
(10, 'cse', 0),
(11, 'ece', 0),
(12, 'eee', 0),
(13, 'food_tech', 0),
(14, 'information_technology', 0),
(15, 'management', 0),
(16, 'mechanical', 0),
(17, 'physics', 0),
(18, 'physical', 0),
(19, 'transport', 0),
(20, 'canteen', 0),
(21, 'library', 0),
(22, 'cleaning', 0),
(23, 'hostel', 0),
(24, 'english', 0),
(25, 'maths', 0),
(0, 'Jartan', 0),
(0, 'Jartan', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `emp_id` (`emp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
