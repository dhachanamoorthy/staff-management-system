<?php
	$name=$_POST['name'];
	$dob=$_POST["dob"];
	$gender=$_POST["gender"];
	$email=$_POST["email"];
	$psw=$_POST["psw"];
	$role=$_POST["role"];
	$position=$_POST["position"];
	$department=$_POST["department"];
	$emp_id=$_POST["emp_id"];
	$encrypt=base64_encode($psw);
	$mobile=$_POST["phonenumber"];
    $con=new mysqli("localhost","root","","xoho");
	$sql="INSERT INTO employee(name,gender,email,mobile,password,role,position,emp_id,dept) VALUES('$name','$gender','$email',$mobile,'$encrypt','$role','$position','$emp_id','$department')";
	if(!$con){
		die("Connection failed :".mysqli_connect_error());
	}
	if(!mysqli_query($con,$sql)){
		echo '<br>failed to sign up...';
		
	}
	else
	{
        echo "successfully signed up";

	}	
?> 
