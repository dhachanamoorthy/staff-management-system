<?php
		$con=new mysqli("localhost","root","","xoho");
?>